package com.cg.lambdas;

public class a_b {
	public static void main(String args[])
	{
		SpaceAdder s=st->System.out.println(st.replaceAll(""," ").trim());
		s.sadder("Punit");

}}
