package com.cg.lambdas;

//@FunctionalInterface
public interface Power {
	
		public double findPower(int a,int b);
		
	}


