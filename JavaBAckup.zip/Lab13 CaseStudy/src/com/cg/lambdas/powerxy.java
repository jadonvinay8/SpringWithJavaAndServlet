package com.cg.lambdas;

public class powerxy {
	public static void main(String srg[])
	{
		
	
	 Power pow=(a,b)->Math.pow(a,b);
	 double r=pow.findPower(2,4);
	 System.out.println(r);
	

    
	}

}
