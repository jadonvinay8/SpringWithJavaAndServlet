package com.cg.lambdas;

public interface UserPass {
	public void verify(String u,String p);

}
