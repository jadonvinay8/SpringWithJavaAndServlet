package com.cg.lambdas;

public interface SpaceAdder {
	public void sadder(String st);

}
