package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class findAccountTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
