package cg;

import java.sql.*;
import java.util.Scanner;

public class Demo5 {

	public static void main(String[] args) throws SQLException{
		
		Connection con = null;
		PreparedStatement update = null;
		PreparedStatement select = null;
		
		try {
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver()); java8 automatically loads thr driver
			
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String pass = "hr";	
			
			con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connected successfully to the database");
			System.out.println();
			
			con.setAutoCommit(false); //tells that don't commit after every DML statement
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter account id: ");
			int id = sc.nextInt();
			
			select = con.prepareStatement("select * from account where aid = ?");
			select.setInt(1, id);
			ResultSet rs1 = select.executeQuery();
			double bal1 = 0;
			if(rs1 != null) {
				if(rs1.next()) {
					System.out.println(rs1.getString(3));
					bal1 = rs1.getDouble("balance");
					System.out.println("your balance is: "+ bal1);
				}
			}
			
			System.out.println("Enter another account id: ");
			int id1 = sc.nextInt();
			
			select = con.prepareStatement("select * from account where aid = ?");
			select.setInt(1, id1);
			ResultSet rs2 = select.executeQuery();
			double bal2 = 0;
			if(rs2 != null) {
				if(rs2.next()) {
					System.out.println(rs2.getString(3));
					bal1 = rs2.getDouble("balance");
					System.out.println("your balance is: "+ bal2);
				}
			}
			
			System.out.println();
			System.out.println("Enter the amount to transfer from first account to another: ");
			double amount = sc.nextDouble();
			
			update = con.prepareStatement("update account set phoneNum = ?, accountHolder = ?, balance = ? where aid = ?");
			update.setString(1, rs1.getString("phoneNum"));
			update.setString(2, rs1.getString("accountHolder"));
			update.setDouble(3, rs1.getDouble("balance") - amount);
			update.setInt(4, rs1.getInt("aid"));
			int num = update.executeUpdate();
			System.out.println("Accounts updated: " + num);
			
			update.setString(1, rs2.getString("phoneNum"));
			update.setString(2, rs2.getString("accountHolder"));
			update.setDouble(3, rs2.getDouble("balance") + amount);
			update.setInt(4, rs2.getInt("aid"));
			num += update.executeUpdate();
			System.out.println("Accounts updated: " + num);
			
			
			/*
			System.out.println("Enter phone number: ");
			String phone = sc.next();
			System.out.println("Enter account holder name: ");
			String name = sc.next();
			System.out.println("Enter account balance: ");
			double balance = sc.nextDouble();
			
			//dynamic query
			String sqlQuery = "insert into account values(?,?,?,?)";
			
			PreparedStatement st = con.prepareStatement(sqlQuery);
			st.setInt(1, id);
			st.setString(2, phone);
			st.setString(3, name);
			st.setDouble(4, balance);
			
			int insertedRec = st.executeUpdate(); //returns number of rows added
			System.out.println("Number of Inserted Records: " + insertedRec);
			
			*/
			
			con.commit();
			
			sc.close();


		}
		catch(SQLException e){
			con.rollback();
			System.out.println(e.getMessage() + " " + e.getErrorCode() + " " + e.getSQLState());
			e.printStackTrace();
		}
		finally {
			System.out.println("Closing Connection");
			if(con != null)
				con.close();
		}

	}

}
