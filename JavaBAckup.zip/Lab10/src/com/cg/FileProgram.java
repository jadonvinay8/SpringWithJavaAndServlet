package com.cg;

public class FileProgram {

	public static void main(String[] args) {
		
		CopyDataThread copy = new CopyDataThread();
		Thread t = new Thread(copy);
		t.start();
	}

}
