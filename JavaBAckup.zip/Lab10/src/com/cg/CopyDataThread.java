package com.cg;

import java.io.*;
import java.util.concurrent.TimeUnit;

public class CopyDataThread implements Runnable  {

	@Override
	public void run()  {
		FileReader fr;
		BufferedReader br;
		FileWriter fw;
		int character;
		int count = 0;
		
		try {
			fr = new FileReader("D:/source.txt");
			br = new BufferedReader(fr);
			fw = new FileWriter("D:/target.txt",true);
	        while ( (character = br.read())!= -1) {
	        	count++;
	        	if(count == 10) {
	        		System.out.println("10 characters copied");
	        		count = 0;
	        		TimeUnit.SECONDS.sleep(5);
	        	}
	        	
	        	fw.write(character);
	        	fw.flush();
	        }
	        br.close();
	        fw.close();
	        fr.close();

		}
		catch(IOException | InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	
}
