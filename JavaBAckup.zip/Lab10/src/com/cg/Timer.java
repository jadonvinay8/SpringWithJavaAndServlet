package com.cg;

import java.util.concurrent.TimeUnit;

public class Timer implements Runnable{

	public void run() {
		for(int i = 1 ; i<=10 ; i++) {
			System.out.println(i);
			if(i==10) {
				i = 0;
				System.out.println("10 seconds elapsed");
			}
			try {
				TimeUnit.SECONDS.sleep(1);
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}		
		}
	}
}
