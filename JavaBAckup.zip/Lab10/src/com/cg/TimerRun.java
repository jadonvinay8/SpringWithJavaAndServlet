package com.cg;

public class TimerRun {

	public static void main(String[] args) {

		Timer t = new Timer();
		Thread th = new Thread(t);
		th.start();
	}

}
