package com.cg;

import java.util.*;
import com.cg.bean.Account;

public class BalanceComparator implements Comparator<Account> {

	@Override
	public int compare(Account a, Account b) {
		// 
		
		double diff = a.getBalance() - b.getBalance();
		if (diff > 0)
			return 1;
		else if (diff < 0)
			return -1;
		else
			return 0;
	}
	
	
}
