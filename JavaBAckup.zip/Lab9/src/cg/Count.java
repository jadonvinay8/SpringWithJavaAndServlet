package cg;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Count {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter String");
		String s = sc.readLine();
		char ch[]=s.toCharArray();
		Count c=new Count();
		c.countCharacter(ch);
	}
	public Map<Character,Integer> countCharacter(char ch[])
	{
		Map<Character,Integer> m=new HashMap<Character,Integer>();
		List<Character> l=new ArrayList<Character>();
		Set<Character> s=new HashSet<Character>();
		for(int i=0;i<ch.length;i++)
		{
			l.add(ch[i]);
			s.add(ch[i]);
		}
		Collections.sort(l);
		for(Character a:s)
		{	
			m.put(a, Collections.frequency(l, a));
		}
		System.out.println(m);
		return m;
	}

}
