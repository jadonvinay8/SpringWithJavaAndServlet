package com.capgemini.dao;

import java.util.Map;

import com.capgemini.bean.Order;

public interface DaoInterface {

	public int addOrder(Order bean);
	public void getAllOrders();
	public void deleteAOrder(Order bean);
}
