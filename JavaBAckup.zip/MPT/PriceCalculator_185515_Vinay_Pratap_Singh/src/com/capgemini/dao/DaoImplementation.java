package com.capgemini.dao;

import java.util.Map;
import java.util.TreeMap;

import com.capgemini.bean.Order;
import com.capgemini.service.OrderService;
import com.capgemini.service.Service;

public class DaoImplementation implements DaoInterface {

	Map<Integer, Order> map = new TreeMap<>();

	@Override
	public int addOrder(Order bean) {
		map.put(bean.getId(), bean);
		System.out.println(map);
		return 1;
	
		
	}

	@Override
	public void getAllOrders() {
		System.out.println(map);
	}

	@Override
	public void deleteAOrder(Order bean) {
		int id = bean.getId();
		map.remove(id);
		System.out.println("Record deleted successfully");
	}

	
}
