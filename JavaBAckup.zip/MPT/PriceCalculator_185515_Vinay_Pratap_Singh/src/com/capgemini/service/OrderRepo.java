package com.capgemini.service;

import com.capgemini.bean.Order;

public interface OrderRepo {

	int saveOrder(Order bean);
}
