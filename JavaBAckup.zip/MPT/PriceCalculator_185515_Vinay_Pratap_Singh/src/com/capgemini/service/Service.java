package com.capgemini.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.capgemini.bean.Order;
import com.capgemini.dao.DaoImplementation;
import com.capgemini.dao.DaoInterface;
import com.capgemini.exception.InvalidQuantityException;

public class Service implements OrderService, OrderRepo {

	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	DaoInterface dao = new DaoImplementation();
	Map<Integer, Order> map = new TreeMap<>();
	
	@Override
	public int saveOrder(Order bean) {
		// TODO Auto-generated method stub
		return dao.addOrder(bean);
	}

	@Override
	public int calculateOrder(Order bean) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public Order getOrderById(int id){
		return map.get(id);
	}
	
	public double acceptPrice() {
		double price = 0; 
		while(true) {
			try {
				price = Double.parseDouble(br.readLine());
				break;
			}
			catch(NumberFormatException | IOException e) {
				System.out.println("Enter a number and try again....");
			}
		}
		while(true) {	
			if(price > 0)
				break;
			else
				System.out.println("Price can't be negative..try again");
		}
		
		return price;
	}
	
	public int acceptQuantity() throws InvalidQuantityException {
		int qty = 0;
		while(true){
			try {
				qty = Integer.parseInt(br.readLine());
				break;
			}
			catch(NumberFormatException | IOException e) {
				System.out.println("Enter a number and try again....");
			}
		}
		while(true) {
			if(qty<1)
				throw new InvalidQuantityException(qty, "quantity can't be less than 1");
			else 
				break;
		}
		return qty;
		
	}

}
