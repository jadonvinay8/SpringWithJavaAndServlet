package com.capgemini.service;

import com.capgemini.bean.Order;

public interface OrderService {

	int calculateOrder(Order bean);
	
	public default void printRecords(Order bean) {
		System.out.println("-----------------------------------------------------------");
		System.out.println();
		System.out.println("Record for Order id: " + bean.getId());
		System.out.println();
		System.out.println("Price \t Quantity \t Amount(in INR) \t Charges ");
		System.out.println(bean.getPrice() + "\t" + bean.getQuantity() + "\t\t" + bean.getAmount() + "\t\t\t" + bean.getCharges());
		System.out.println("-----------------------------------------------------------");
		System.out.println();
		
	}
}
