package com.capgemini.exception;

public class InvalidQuantityException extends Exception {

	int quantity; 
	
	public InvalidQuantityException(int quantity, String msg) {
		super(msg);
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "InvalidQuantityException [quantity=" + quantity + "]  is lesser than 1";
	}
	
}
