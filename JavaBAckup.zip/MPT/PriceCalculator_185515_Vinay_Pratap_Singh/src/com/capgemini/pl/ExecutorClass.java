package com.capgemini.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.TreeMap;


import com.capgemini.bean.Order;
import com.capgemini.dao.DaoImplementation;
import com.capgemini.dao.DaoInterface;
import com.capgemini.exception.InvalidQuantityException;
import com.capgemini.service.Service;

public class ExecutorClass {

	public static void main(String[] args) {

		Service service = new Service();
		DaoInterface dao = new DaoImplementation();
		
		Order bean;
		
		Map<Integer, Order> map = new TreeMap<>();

		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int choice = 0;
		while(true) {
		System.out.println("Choose your option...");
		System.out.println();
		System.out.println("1. Add an order");
		System.out.println("2. View all orders");
		System.out.println("3. Find order by id");
		System.out.println("4. Delete an order");
		System.out.println("5. Exit");

	
	
			try {
					choice = Integer.parseInt(br.readLine());
	
			}
			catch(Exception e) {
				System.out.println("Invalid Input....try again by entering a whole number only.......");
			}
			
			switch(choice) {
				case 1: System.out.println("Enter Price in dollars: ");
						double price = service.acceptPrice();
						
						int qty = 0;
						System.out.println("Enter quantity: ");
						try {
							qty = service.acceptQuantity();
						}
						catch (InvalidQuantityException e) {
							System.out.println(e.getMessage());
						}
						bean = new Order(price,qty);
						service.saveOrder(bean);
						break;
						
				case 2: dao.getAllOrders();
						
						break;
						
				case 3: System.out.println("enter the id: ");
						int id = 0;
						try {
							id = Integer.parseInt(br.readLine());
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					
						bean = service.getOrderById(id);
						service.printRecords(bean);
						
						
				case 4: System.out.println("Enter the id: ");
						id = 0;
						try {
							id = Integer.parseInt(br.readLine());
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						bean = service.getOrderById(id);
						dao.deleteAOrder(bean);
						break;
	
				case 5: System.out.println("Exiting program...");
						System.exit(0);
						
			}
			
		
		}
		
	}

}
