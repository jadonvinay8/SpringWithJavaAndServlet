package com.capgemini.bean;

import com.capgemini.service.OrderService;
import com.capgemini.service.Service;

public class Order {

	private int id = (int)(Math.random()*100000);
	
	private double price;
	private int quantity;
	
	private double amount; 
	private double charges; 
	OrderService service = new Service();
	
	public Order() {
		//default constructor
	}

	public Order(double price, int quantity) {
		super();
		this.price = price;
		this.quantity = quantity;
		
		//setting amount as price times quantity and multiplying by 75 to convert dollars to INR
		amount = price * quantity * 75;
		
		//calculating currency conversion charges as 1.25% of amount
		charges = (1.25/100) * amount;
		
		service.printRecords(this);
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	//not providing setters for id, amount and charges as user is not supposed to set them.
	public int getId() {
		return id;
	}

	public double getAmount() {
		return amount;
	}

	public double getCharges() {
		return charges;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", price=" + price + "$, quantity=" + quantity + ", amount=" + amount + "INR, charges="
				+ charges + "INR]";
	}
	
	
}

