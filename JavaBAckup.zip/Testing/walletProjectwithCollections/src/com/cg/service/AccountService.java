package com.cg.service;

import java.util.Map;

import com.cg.Exception.InsufficientFundException;
import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOimpl;

public class AccountService implements Gst, Transactions {
	
	AccountDAO dao = new AccountDAOimpl();
	
	@Override
	public double withdraw(Account ob, double amount) throws InsufficientFundException {
		double new_balance = ob.getBalance();
		if(amount > 0) {
			new_balance = ob.getBalance() - amount;
			if(new_balance < 1000.00) {
				new_balance = ob.getBalance();
				System.out.println("Insufficient Balance");
				throw new InsufficientFundException("insufficient fund, cant process withdraw", new_balance);
				
			}
			else
				ob.setBalance(new_balance);
		}
		return new_balance;
	}

	public double deposit(Account ob, double amount) {
		if(amount >= 0) {
			double new_balance = ob.getBalance() + amount;
			ob.setBalance(new_balance);
			return new_balance;
		}
		else {
			System.out.println("can't process deposit as amount is negative");
			return ob.getBalance(); 
		}
	}

	@Override
	public double[] transferMoney(Account from, Account to, double amount) {// INCOMPLETE
		double[] arr = new double[2];
		if(amount < 0) {
			System.out.println("Invalid withdrawal..try again");
			
			arr[0] = from.getBalance();
			arr[1] = to.getBalance();
			
		}
		else {
			double new_balance = from.getBalance() - amount;
			if(new_balance<1000.00) {
				
				System.out.println("Insufficient Balance");
				arr[0] = from.getBalance();
				arr[1] = to.getBalance();
				
			}
			else {
				from.setBalance(new_balance);
				arr[0] = from.getBalance();
				
				double b2 = to.getBalance()+amount;
				to.setBalance(b2);
				
				arr[1] = to.getBalance();
			}
		}
		
		return arr;
	}

	@Override
	public double calculateTax(double percent, double amount) {
		// 
		return amount*Gst.PCT_5;
	}

	@Override
	public boolean addAccount(Account a) {
		// 
		return dao.addAccount(a);
	}

	@Override
	public boolean deleteAccount(Account a) {
		// 
		return dao.deleteAccount(a);
	}

	@Override
	public Account findAccount(String phone) {
		// 
		return dao.findAccount(phone);
	}

	@Override
	public Map<String, Account> getAllAccounts() {
		// 
		return dao.getAllAccounts();
	}

}
