
public class Validator {

	public boolean validateNum(String data) {
		return data.matches("\\d+");
				
	}
	
	public boolean isPallindrome(String data) {
		StringBuilder ss = new StringBuilder(data);
		String rev = ss.reverse().toString();
		return data.equals(rev);
	}
	
	public int getSizeInML(Size size) {
		System.out.println("size: "+ size.getMl());
		return size.getMl();
	}
	
}
