import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

class ValidatorTest {

	@Test
	void test1() {
		;Validator v = new Validator();
		String data = "100";
		Assumptions.assumeFalse(data == null);
		System.out.println("assert true");
		assertTrue(v.validateNum(data));
		
		System.out.println("assert false");

		data = "abc";
		assertFalse(v.validateNum(data));
	}
	
	@Test
	void test2() {
		Validator v = new Validator();
		//assertTrue(v.validateNum(null));
		assertThrows(NullPointerException.class, ()->v.validateNum(null));
	}
	/*
	 //()->v.validateNum(null)
	 class ________ implements Executable{
	 	public boolean execute(){
	 		return v.validateNum(null);
	 	}
	 }
	  */
	@ParameterizedTest
	@ValueSource(strings = {"racecar","naman","madam"})
	void test3(String data) {
		Validator v = new Validator();
		System.out.println("test palindrome with data: " +data);
		assertTrue(v.isPallindrome(data));
	}
	
	@ParameterizedTest
	@CsvSource({"4,5","10,20","5, 78","45,32"})
	void test4(int a, int b) {
		Calculator c = new Calculator();
		System.out.println("test add with value a: "+ a + " & b: "+b);
		assertTrue(c.add(a, b)>=9);
	}
	
	private static Stream<Arguments> testWithOutput(){
		return Stream.of(
				Arguments.of(4,5,9),
				Arguments.of(100,500,600));
	}
	
	@ParameterizedTest
	@MethodSource("testWithOutput")
	void testWithMethods(int a, int b, int op) {
		Calculator c = new Calculator();
		System.out.println("test add with value a: "+ a + " & b: "+b + " &result: " + op);
		assertEquals(op,c.add(a, b) );
	}
	
	@ParameterizedTest
	@EnumSource(Size.class)
	void testWithEnum(Size size) {
		Validator v = new Validator();

		System.out.println("test enum value: " + size);
		assertEquals(size.getMl(),v.getSizeInML(size) );
	}
	
	
	
	
	
}
