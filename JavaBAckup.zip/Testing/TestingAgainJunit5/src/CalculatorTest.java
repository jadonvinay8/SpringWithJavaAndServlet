import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	static Calculator c;
	
	@BeforeAll        //junit4: @BeforeClass
	public static void beforeAllTest() {
		System.out.println("Before all tests");
		c = new Calculator();
	}
	
	@AfterAll
	public static void afterAllTest() {
		System.out.println("After all tests");
		c = null;
	} 
	@BeforeEach     //junit 4: @Before
	public void beforeEachTest() {
		System.out.println("Before each test");
		//c = new Calculator();
	}
	
	@AfterEach        //junit 4: @After
	public void afterEachTest() {
		System.out.println("After each test");
		//c = null;
	}
	
	@RepeatedTest(5)
	//@Test
	void test() {
		
		System.out.println("test add");
		assertEquals(9, c.add(4, 5 ));
	}
	
	@Test
	void testadd1() {
		

		System.out.println("test add 1");

		assertTrue(c.add(4,5)>0);
		assertTrue(c.add(4,-5)>=0);

	}
	@Disabled
	@Test
	public void testIdGenerator() {
		System.out.println("id test");
		assertTrue(c.idgenerator()>=0);

	}

}
