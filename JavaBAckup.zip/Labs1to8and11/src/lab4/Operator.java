package lab4;

public class Operator {
	
	public static int addCubeOfDigits(int n) {
		int sum = 0;
		String s = Integer.toString(n);
		char[] c = s.toCharArray();
		for(int i=0 ; i<c.length ; i++) {
			int num = Integer.parseInt(Character.toString(c[i]));
			sum += Math.pow(num, 3);
		}
		return sum;
	}
	
	public static void main(String[] args) {
		System.out.println(Operator.addCubeOfDigits(1111111));
	}
}
