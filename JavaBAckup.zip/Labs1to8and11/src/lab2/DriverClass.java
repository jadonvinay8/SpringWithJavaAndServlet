package lab2;

public class DriverClass {

	public static void main(String[] args) {
		// Client program............
	
	}

}
