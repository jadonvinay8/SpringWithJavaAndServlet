package lab5;
import java.math.BigInteger;
import java.util.Scanner;

public class Exercises {
	
	public void TrafficLights() {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Choose on of these lights: ");
		System.out.println("1. Red ");
		System.out.println("2. Yellow ");
		System.out.println("3. Green ");
		int choice = input.nextInt();
		
		switch(choice) {
		case 1: 		System.out.println("Stop.......... ");
						break;
		case 2: 		System.out.println("Wait.......... ");
						break;
		case 3: 		System.out.println("Go.......... ");
						break;
		default:		System.out.println("Invalid choice...");
		}
		input.close();
	}
	
	public int nonRecFibonnaci(int n) {
		
		int a = 1;
		int b = 1;
		for(int i=2 ; i<=n ; i++ ) {
			int c = a;
			a = b;
			b = c+b;
			
		}
		return a;
	}

	public int recFibonnaci(int n) {
		if(n == 1)
			return 1;
		else if(n == 0)
			return 0;
		else
			 return recFibonnaci(n-1) + recFibonnaci(n-2);
	}
	
	public void printPrimes(int n) {
		for(int i=0 ; i<n ; i++) {
			BigInteger j = new BigInteger(String.valueOf(i));
			if(j.isProbablePrime(1000)) //bigger the argument, more is the certainity 
				System.out.println(j);
			
		}
	}
	
	public void validateName(String s) {
		String pattern = "[a-zA-Z][a-zA-Z ']*";
		if(s.matches(pattern))
			System.out.println(s +" is a valid name...");
		else
			try {
				throw new BlankNameException();
			} 
			catch (BlankNameException e) {
				e.printStackTrace();
			}
			
	}
	
	public void validateAge(int age, String name) {
		if(age > 15)
			System.out.println("you are welcome, " +name);
		else
			try {
				throw new UnderAgeException(age);
			} 
			catch (UnderAgeException e) {
				e.printStackTrace();
			}
	}
	
	public void salaryValidator(int salary) {
		if(salary < 3000)
			try {
				throw new EmployeeException(salary);
			} 
			catch (EmployeeException e) {
				e.printStackTrace();
			}
		else
			System.out.println("Your salary is not lesser than 3000.....congrats");
	}
	
	
}