package lab5;

public class Driver {

	public static void main(String[] args) {
		
		Exercises test = new Exercises();
		
		System.out.println(test.nonRecFibonnaci(7));
		System.out.println(test.recFibonnaci(7));
		//test.printPrimes(100);
		test.validateName("D'souza");
		test.validateAge(16, "D'souza");
		test.salaryValidator(20000);
	}
}