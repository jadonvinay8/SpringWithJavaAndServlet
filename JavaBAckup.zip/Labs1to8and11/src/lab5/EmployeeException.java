package lab5;

public class EmployeeException extends Exception {

	int salary;
	
	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(int salary) {
		super();
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "EmployeeException [salary=" + salary + "]" + " salary is lesser than 3000";
	}
	
	
}
