package lab5;

public class UnderAgeException extends Exception {
	
	int age; 
	
	public UnderAgeException() {
		// TODO Auto-generated constructor stub
	}

	public UnderAgeException(int age) {
		super();
		this.age = age;
	}

	@Override
	public String toString() {
		return "UnderAgeException [age=" + age + "]" + "age is not greater than 15";
	}
	
		
}