package lab8;

import java.io.*;


public class ReadFile {

	public static void main(String[] args) throws IOException {

		try {
			
			FileReader fr = new FileReader("D:\\file.txt");
			BufferedReader br = new BufferedReader(fr);
			String s; 
			int l=1;
			while((s = br.readLine())!=null)
				System.out.println((l++)+" "+s);
			
			br.close();
			fr.close();
		
	}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}

}
