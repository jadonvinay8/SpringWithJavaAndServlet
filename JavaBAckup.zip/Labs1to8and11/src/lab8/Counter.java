package lab8;

import java.io.*;

public class Counter {

	public static void main(String[] args) throws IOException {

		try {
			FileReader fr=new FileReader("D:\\file.txt");
			BufferedReader br=new BufferedReader(fr);
			
			int st;
			int l = 1,
			words = 0,
			lines = 1;
			
			while((st=br.read())!=-1)
			{
				l++;
				if(st==' ')
				{
					words++;
				}
				if(st=='\n')
				{
					lines++;
				}
			
			}
			System.out.println((l-lines)+" "+words+" "+lines);
			br.close();
			fr.close();
		
	}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}

}
