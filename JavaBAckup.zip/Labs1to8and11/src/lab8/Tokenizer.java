package lab8;

import java.util.*;

public class Tokenizer {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("enter the string");
		String s1 = input.nextLine();
		StringTokenizer s2 = new StringTokenizer(s1," ");
		
		int sum =0 ;
		
		while(s2.hasMoreElements())
		{
			sum=sum+Integer.parseInt(s2.nextToken());
		}
		System.out.println(sum);
		
		input.close();
	}

}
