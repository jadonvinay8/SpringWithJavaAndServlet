package lab3;
import java.util.Arrays;

public class Methods {

	public int secondSmallest(int[] nums) {
		Arrays.sort(nums);
		return nums[1];
	}
	
	public String[] stringOperation(String[] strings) {
		Arrays.sort(strings);
		int len = strings.length;
		int halfway = 0;
		
		if(len%2 == 0)
			halfway = len/2;
		else
			halfway = (len+1)/2;
		
		for(int i=0 ; i<halfway ; i++)
			strings[i] = strings[i].toUpperCase();
		
		for(int i=halfway ; i<len ; i++)
			strings[i] = strings[i].toLowerCase();
		
		return strings;
	}
	
	public int[] sortedArray(int[] nums) {
		int len = nums.length;
		String[] numStrings = new String[len];
		for(int i=0 ; i<len ; i++) {
			numStrings[i] = Integer.toString(nums[i]);
			StringBuilder ss = new StringBuilder(numStrings[i]);
			numStrings[i] = ss.reverse().toString();
		}	
		
		for(int i=0 ; i<len ; i++) {
			nums[i] = Integer.parseInt(numStrings[i]);
			
		}
		Arrays.sort(nums);
		return nums;
		
	}
	

}
