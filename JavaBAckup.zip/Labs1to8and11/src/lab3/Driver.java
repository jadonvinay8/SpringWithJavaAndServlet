package lab3;

public class Driver {

	public static void main(String[] args) {
		
		Methods test = new Methods();
		int[] dummy = {21,13,84,78,86};
		int[] newer = test.sortedArray(dummy);
		for (int s: newer)
			System.out.println(s);
	}

}
