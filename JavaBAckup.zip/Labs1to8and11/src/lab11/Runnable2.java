package lab11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Runnable2 extends DataThread{

	public static void main(String[] args) {

		ExecutorService executor=Executors.newSingleThreadExecutor();
		DataThread c=new DataThread();
		Runnable r=c::run;
		executor.execute(r);
		executor.shutdown();
	}

}
