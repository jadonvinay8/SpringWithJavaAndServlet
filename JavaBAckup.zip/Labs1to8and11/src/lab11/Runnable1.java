package lab11;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Runnable1 extends DataThread {

	public static void main(String[] args) {

		
		Executor executor=Executors.newSingleThreadExecutor();
		DataThread c=new DataThread();
		Runnable r=c::run;
		executor.execute(r);
		
	}

}
