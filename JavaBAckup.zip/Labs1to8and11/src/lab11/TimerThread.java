package lab11;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class TimerThread extends MainThread {

	public static void main(String[] args) {

		Executor executor=Executors.newSingleThreadExecutor();
		MainThread c=new MainThread();
		Runnable r=c::run;
		executor.execute(r);
	}

}
