package lab11;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TimerThread2 {

	public static void main(String[] args) {


		ExecutorService executor = Executors.newSingleThreadExecutor();
		MainThread c = new MainThread();
		Runnable r=c::run;
		executor.execute(r);
		executor.shutdown();
	}

}
