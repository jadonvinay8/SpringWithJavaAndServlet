package com.cg.dao;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import com.cg.bean.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao {

	Connection con = DBUtil.getConnection();
	Login obj;
	
	@Override
	public Login logInUser(Login user) {
		// TODO Auto-generated method stub
		String query = "Select * from UserDetails";
		try{
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()){
				String name = rs.getString(1);
				String pass = rs.getString(2);
				if(name.equals(user.getUsername()) && pass.equals(user.getPassword())){
					obj = user;
					break;
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return obj;
	}

	
}
