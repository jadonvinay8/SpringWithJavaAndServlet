package com.cg.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.demo.EmployeeDao;
import com.cg.demo.EmployeeService;

@Configuration //replacement of spring.xml
@ComponentScan("com.cg.demo")   //pick all the classes from this package
public class AppConfig {

/*	---not required when @ComponentScan is used---
	@Bean
	public EmployeeDao dao(){
		return new EmployeeDao();
	}
	
	@Bean
	public EmployeeService service(){
		EmployeeService service = new EmployeeService();
		service.setDao(dao());
		return service;
	}
*/
}
