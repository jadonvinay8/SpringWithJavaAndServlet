package com.cg.demo;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	private EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}

	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}
}
