package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	

   /** This single line inside main method does the following:
	 * 1. Create AnnotationConfigApplicationContext
	 * 2. Uses @ComponentScan for all child packages
	 * 		2.1 Picks HelloController class
	 * 		2.2 Does request mapping to "/"
	 * 3. reads application.properties
	 * 4. launches embedded Tomcat and deploy HelloController
	 * 5. Waits for you to terminate the process
	 */
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
	}

}
