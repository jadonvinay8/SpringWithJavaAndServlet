package com.cg.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;

@RestController  //@RestController returns just model and not view
public class HelloController {
	
	@GetMapping("/")
	public String hello() {
		return "hello world";
	}
	
	@GetMapping("/product")
	public List<Product> getProducts(){
		List<Product> list = new LinkedList<>();
		list.add(new Product(101,"Pizza","Nice",200.00));
		list.add(new Product(102,"Windows","Fine",2000.00));
		list.add(new Product(103,"Phone","Wooooow",20000.00));
		list.add(new Product(104,"Car","dedo",200000.00));

		return list;
		
	}
}
