package com.cg.entities;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Product {
	
	@NotNull
	@Max(value=10000,message="id can't be greater than 100000")
	private Integer productId;
	
	@NotEmpty
	private String name;
	
	@Size(min=3,max=100,message="must have at least 3 characters and cannot have more than 100")
	private String description;
	
	@NotNull
	private Double price;
	public Product(Integer productId, String name, String description,
			Double price) {
		super();
		this.productId = productId;
		this.name = name;
		this.description = description;
		this.price = price;
	}
	public Product()
	{
		super();
		//Todo Auto-generated stub
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	

}
