package com.cg;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cg.entities.Country;

public class Main {
	public static final String BASE_URL = "http://localhost:8085/countries";

	public static void main(String[] args) {
		RestTemplate template = new RestTemplate();
		Country country = template.getForObject(BASE_URL+"/code/IN", Country.class);
		System.out.println("Country found: " + country.getName());
		Country c = new Country("MN","Narnia","Antarctica","Wakad");
		ResponseEntity<String> s = template.postForEntity(BASE_URL+"/new", c, String.class);
		System.out.println(s);
		
	}

}
