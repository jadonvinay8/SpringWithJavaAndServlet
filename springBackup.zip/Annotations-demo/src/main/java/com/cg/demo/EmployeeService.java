package com.cg.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmployeeService {

	private EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}
	
	@Autowired
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
		System.out.println("Performing setter injection");
	}
	
	
}
