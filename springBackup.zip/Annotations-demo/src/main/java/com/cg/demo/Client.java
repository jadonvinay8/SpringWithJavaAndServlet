package com.cg.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		EmployeeDao dao = context.getBean(EmployeeDao.class);
		EmployeeService service = context.getBean(EmployeeService.class);
		
		System.out.println("DAO: " + dao);
		System.out.println("Service: " + service);
	}

}
