package com.cg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RestTest {

	@Test
	void test() {
		fail("not implemented");
	}

}
